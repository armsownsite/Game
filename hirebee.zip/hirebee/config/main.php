<?php
$config = [

    'id' => 'basic',
    'name'=>'Snippet Guru',
     .....
];

 
