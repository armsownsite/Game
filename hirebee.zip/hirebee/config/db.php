<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=pol_form',
    'username' => 'root',
    'password' => 'Emily070116!@#',
    // Schema cache options (for production environment)
    //'enableSchemaCache' => true,
    //'schemaCacheDuration' => 60,
    //'schemaCache' => 'cache',
];




// return [
// 'components' => [
//     'db1' => [
//         'class' => 'yii\db\Connection',
//         'dsn' => 'mysql:host=localhost;dbname=mc', //maybe other dbms such as psql,...
//         'username' => 'norq',
//         'password' => 'Norq123!@#',
//     ],
//     'db2' => [
//         'class' => 'yii\db\Connection',
//         'dsn' => 'mysql:host=localhost;dbname=mc', // Maybe other DBMS such as psql (PostgreSQL),...
//         'username' => 'norq',
//         'password' => 'Norq123!@#',
//     ],
// ],
// ];
